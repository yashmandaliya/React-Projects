import express, { Request, Response } from "express";
import verifyToken from "../middleware/auth";
import Hotel from "../models/hotel";
import { HotelType } from "../shared/types";
import User from "../models/user";

const router = express.Router();

// /api/my-bookings
router.get("/", verifyToken, async (req: Request, res: Response) => {
  try {
    const hotels = await Hotel.find({
      bookings: { $elemMatch: { userId: req.userId } },
    });

    const results = hotels.map((hotel) => {
      const userBookings = hotel.bookings.filter(
        (booking) => booking.userId === req.userId
      );

      const hotelWithUserBookings: HotelType = {
        ...hotel.toObject(),
        bookings: userBookings,
      };

      return hotelWithUserBookings;
    });

    res.status(200).send(results);
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "Unable to fetch bookings" });
  }
});


// router.get("/", verifyToken, async (req: Request, res: Response) => {
//   try {
//     const hotels = await Hotel.find(); // Fetch all hotels

//     const results = hotels.map((hotel) => {
//       const hotelWithAllBookings: HotelType = {
//         ...hotel.toObject(),
//         bookings: hotel.bookings, // Return all bookings
//       };

//       return hotelWithAllBookings;
//     });

//     res.status(200).send(results);
//   } catch (error) {
//     console.log(error);
//     res.status(500).json({ message: "Unable to fetch bookings" });
//   }
// });



router.get("/all-bookings", verifyToken, async (req: Request, res: Response) => {
  try {
    const hotels = await Hotel.find();

    const results = hotels.map((hotel) => {
      const hotelWithAllBookings: HotelType = {
        ...hotel.toObject(),
        bookings: hotel.bookings,
      };

      return hotelWithAllBookings;
    });

    res.status(200).send(results);
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "Unable to fetch bookings" });
  }
});

export default router;
