import { useQuery } from "react-query";
import * as apiClient from "../api-client";

const MyBookings = () => {

  // First, get the current user
  const { data: currentUser, isLoading: loadingUser } = useQuery(
    "fetchCurrentUser",
    apiClient.fetchCurrentUser
  );

  // Then, fetch bookings only after currentUser is loaded
  const { data: hotels, isLoading: loadingBookings } = useQuery(
    currentUser?.isAdmin === 1 ? "fetchAllBookings" : "fetchMyBookings",
    currentUser?.isAdmin === 1
      ? apiClient.fetchAllBookingss
      : apiClient.fetchMyBookings,
    {
      enabled: !!currentUser,
    }
  );

  if (loadingUser || loadingBookings) {
    return <div>Loading...</div>;
  }

  if (!hotels || hotels.length === 0) {
    return <span>No bookings found</span>;
  }

  return (
    <div className="space-y-5 p-5">
      <h1 className="text-3xl font-bold text-center mb-5">{currentUser?.isAdmin == 1 ? "All" : "My"}  Bookings</h1>
      <div className="overflow-x-auto">
        <table className="bg-white border border-gray-300 shadow-md rounded-lg">
          <thead>
            <tr className="bg-gray-800 text-white">
              <th className="py-3 px-6">Sr No.</th>
              <th className="py-3 px-6">Booking By User</th>
              <th className="py-3 px-6">Hotel</th>
              <th className="py-3 px-6">Location</th>
              <th className="py-3 px-6">Image</th>
              <th className="py-3 px-6">Check In</th>
              <th className="py-3 px-6">Check Out</th>
              <th className="py-3 px-6">Guests</th>
              <th className="py-3 px-6">Cost</th>
            </tr>
          </thead>
          {/* <tbody>
            {hotels.map((hotel) =>
              
              hotel.bookings.map((booking, index) => (
                
                <tr key={`${hotel._id}-${index}`} className="border-b border-gray-200 text-center">
                  <td className="py-3 px-6 font-semibold">{index + 1}</td>
                {currentUser?.isAdmin == 1}  <td className="py-3 px-6 font-semibold">{booking.firstName}  {booking.lastName}</td>
                  <td className="py-3 px-6 font-semibold">{hotel.name}</td>
                  <td className="py-3 px-6">{hotel.city}, {hotel.country}</td>
                  <td className="py-3 px-6">
                    <img
                      src={hotel.imageUrls[0]}
                      alt={hotel.name}
                      className="w-20 h-20 object-cover rounded-lg mx-auto"
                    />
                  </td>
                  <td className="py-3 px-6">
                    {new Date(booking.checkIn).toDateString()} 
                  </td>
                  <td className="py-3 px-6">
                    {new Date(booking.checkOut).toDateString()}
                  </td>
                  <td className="py-3 px-6">
                    {booking.adultCount} Adults, {booking.childCount} Children
                  </td>
                  <td className="py-3 px-6 font-semibold text-green-600">&#8377;{booking.totalCost} /-</td>
                </tr>
              ))
            )}
          </tbody> */}

          <tbody>
            {(() => {
              let counter = 1;
              return hotels.map((hotel) =>
                hotel.bookings.map((booking) => (
                  <tr key={`${hotel._id}-${counter}`} className="border-b border-gray-200 text-center">
                    <td className="py-3 px-6 font-semibold">{counter++}</td> {/* ✅ Global Sr No */}
                    <td className="py-3 px-6 font-semibold">
                      {booking.firstName} {booking.lastName}
                    </td>
                    <td className="py-3 px-6 font-semibold">{hotel.name}</td>
                    <td className="py-3 px-6">
                      {hotel.city}, {hotel.country}
                    </td>
                    <td className="py-3 px-6">
                      <img
                        src={hotel.imageUrls[0]}
                        alt={hotel.name}
                        className="w-20 h-20 object-cover rounded-lg mx-auto"
                      />
                    </td>
                    <td className="py-3 px-6">
                    {new Date(booking.checkIn).toDateString()} 
                  </td>
                  <td className="py-3 px-6">
                    {new Date(booking.checkOut).toDateString()}
                  </td>
                  <td className="py-3 px-6">
                    {booking.adultCount} Adults, {booking.childCount} Children
                  </td>
                  <td className="py-3 px-6 font-semibold text-green-600">&#8377;{booking.totalCost} /-</td>
                  </tr>
                ))
              );
            })()}
          </tbody>

        </table>
      </div>
    </div>
  );
};

export default MyBookings;
