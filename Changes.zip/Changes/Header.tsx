import { Link } from "react-router-dom";
import { useAppContext } from "../contexts/AppContext";
import SignOutButton from "./SignOutButton";
import * as apiClient from "../api-client";
import { useQuery } from "react-query";

const Header = () => {
  const { isLoggedIn } = useAppContext(); // destructure both together
  const { data: currentUser } = useQuery(
      "fetchCurrentUser",
      apiClient.fetchCurrentUser
    );

    
  return (
    <div className="bg-blue-800 py-6">
      <div className="container mx-auto flex justify-between">
        <span className="text-3xl text-white font-bold tracking-tight">
          <Link to="/">Stayin’ Alive</Link>
        </span>
        <span className="flex space-x-2">
          {isLoggedIn ? (
            <>
              <Link
                className="flex items-center text-white px-3 font-bold hover:bg-blue-600"
                to="/my-bookings"
              >
                { currentUser?.isAdmin == 1 ? "Bookings" : "My Bookings" }
              </Link>

              {/* Ig user is admin then display all hotels */}
              {currentUser?.isAdmin === 1  && (
                <Link
                  className="flex items-center text-white px-3 font-bold hover:bg-blue-600"
                  to="/my-hotels"
                >
                 { currentUser?.isAdmin == 1 ? "Hotels" : "Hotels" }
                </Link>
                  
              )}
               {/* Ig user is admin then display all users */}
               {currentUser?.isAdmin === 1  && (
                <Link
                  className="flex items-center text-white px-3 font-bold hover:bg-blue-600"
                  to="/all-users"
                >
                    { currentUser?.isAdmin == 1 ? "Users" : "Users" }
                </Link>
                  
              )}
              <Link
                className="flex items-center text-white px-3 font-bold hover:bg-blue-600"
                to="/my-profile"
              >
                Profile
              </Link>
              <SignOutButton />
            </>
          ) : (
            <Link
              to="/sign-in"
              className="flex bg-white items-center text-blue-600 px-3 font-bold hover:bg-gray-100"
            >
              Sign In
            </Link>
          )}
        </span>
      </div>
    </div>
  );
};

export default Header;
